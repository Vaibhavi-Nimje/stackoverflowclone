# `yarn install`
use the above command on the client side to install dependencies

# `npm install`
use the above command on the server side to install dependencies

# `yarn start`
use the above command on the client side to run client

# `npm start`
use the above command on the server side to run server